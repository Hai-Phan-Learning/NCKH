#!/usr/bin/env python3

import math
import random

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from nav2_msgs.action import NavigateToPose


class RandomPatrol(Node):

    def __init__(self):

        super().__init__("random_patrol")

        self.client = ActionClient(
            self,
            NavigateToPose,
            "/navigate_to_pose"
        )

        self.get_logger().info("Waiting for NavigateToPose server...")

        while not self.client.wait_for_server(timeout_sec=1.0):
            self.get_logger().info("Waiting...")

        self.get_logger().info("NavigateToPose server connected.")

        #######################################################
        # Giới hạn bản đồ
        #######################################################

        self.min_x = -4.5
        self.max_x = 4.5

        self.min_y = -2.0
        self.max_y = 2.0

        #######################################################

        self.send_random_goal()

    #########################################################

    def send_random_goal(self):

        x = random.uniform(self.min_x, self.max_x)
        y = random.uniform(self.min_y, self.max_y)
        yaw = random.uniform(-math.pi, math.pi)

        goal = NavigateToPose.Goal()

        goal.pose.header.frame_id = "map"
        goal.pose.header.stamp = self.get_clock().now().to_msg()

        goal.pose.pose.position.x = x
        goal.pose.pose.position.y = y
        goal.pose.pose.position.z = 0.0

        goal.pose.pose.orientation.x = 0.0
        goal.pose.pose.orientation.y = 0.0
        goal.pose.pose.orientation.z = math.sin(yaw/2.0)
        goal.pose.pose.orientation.w = math.cos(yaw/2.0)

        self.get_logger().info(
            f"New Goal -> ({x:.2f}, {y:.2f})"
        )

        future = self.client.send_goal_async(
            goal,
            feedback_callback=self.feedback_callback
        )

        future.add_done_callback(
            self.goal_response_callback
        )

    #########################################################

    def goal_response_callback(self, future):

        self.goal_handle = future.result()

        if not self.goal_handle.accepted:

            self.get_logger().warn("Goal rejected.")

            self.send_random_goal()

            return

        self.get_logger().info("Goal accepted.")

        result_future = self.goal_handle.get_result_async()

        result_future.add_done_callback(
            self.result_callback
        )

    #########################################################

    def feedback_callback(self, feedback_msg):

        feedback = feedback_msg.feedback

        self.get_logger().info(
            f"Remaining: {feedback.distance_remaining:.2f} m"
        )

    #########################################################

    def result_callback(self, future):

        status = future.result().status

        if status == 4:
            self.get_logger().info("Goal reached.")
        else:
            self.get_logger().warn(
                f"Navigation finished. Status = {status}"
            )

        self.send_random_goal()


############################################################

def main(args=None):

    rclpy.init(args=args)

    node = RandomPatrol()

    rclpy.spin(node)

    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":

    main()