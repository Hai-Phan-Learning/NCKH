#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node

from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


class AvoidObstacle(Node):

    def __init__(self):

        super().__init__("avoid_obstacle")

        self.publisher = self.create_publisher(
            Twist,
            "/cmd_vel",
            10
        )

        self.subscription = self.create_subscription(
            LaserScan,
            "/scan",
            self.scan_callback,
            10
        )

        self.get_logger().info("Obstacle Avoidance Started")

    ##################################################

    def get_min(self, data):

        valid = [x for x in data if math.isfinite(x)]

        if len(valid) == 0:
            return 3.5

        return min(valid)

    ##################################################

    def scan_callback(self, scan):

        cmd = Twist()

        ranges = list(scan.ranges)

        # -----------------------------
        # Chia LiDAR thành 3 vùng
        # -----------------------------

        front = self.get_min(ranges[0:20] + ranges[-20:])

        left = self.get_min(ranges[40:120])

        right = self.get_min(ranges[240:320])

        # -----------------------------
        # Ngưỡng
        # -----------------------------

        SAFE = 0.50
        DANGER = 0.25

        # ==========================================================
        # 1. Trước mặt trống
        # ==========================================================

        if front > SAFE:

            cmd.linear.x = 0.20
            cmd.angular.z = 0.0

        # ==========================================================
        # 2. Bị chặn phía trước
        # ==========================================================

        else:

            # Bị kẹt cả ba phía
            if front < DANGER and left < SAFE and right < SAFE:

                cmd.linear.x = -0.10

                if left > right:
                    cmd.angular.z = 1.2
                else:
                    cmd.angular.z = -1.2

            # Rẽ trái
            elif left > right:

                cmd.linear.x = 0.05
                cmd.angular.z = 0.8

            # Rẽ phải
            else:

                cmd.linear.x = 0.05
                cmd.angular.z = -0.8

        self.publisher.publish(cmd)

        self.get_logger().info(
            f"Front={front:.2f}  Left={left:.2f}  Right={right:.2f}"
        )


###############################################################


def main(args=None):

    rclpy.init(args=args)

    node = AvoidObstacle()

    rclpy.spin(node)

    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":

    main()