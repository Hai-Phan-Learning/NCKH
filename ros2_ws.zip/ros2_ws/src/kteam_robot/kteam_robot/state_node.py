#!/usr/bin/env python3

import math
import numpy as np

import rclpy
from rclpy.node import Node

from nav_msgs.msg import Odometry
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32MultiArray


class StateNode(Node):

    def __init__(self):

        super().__init__('state_node')

        # ===============================
        # Goal
        # ===============================
        self.goal_x = -4.5
        self.goal_y = 0.0

        # ===============================
        # LiDAR
        # ===============================
        self.scan = [1.0] * 24
        self.scan_ready = False

        # Publisher
        self.state_pub = self.create_publisher(
            Float32MultiArray,
            '/rl_state',
            10
        )

        # Subscribers
        self.create_subscription(
            LaserScan,
            '/scan_rl',
            self.scan_callback,
            10
        )

        self.create_subscription(
            Odometry,
            '/odom',
            self.odom_callback,
            10
        )

        self.counter = 0

        self.get_logger().info("RL State Node Started")

    # =====================================================

    def scan_callback(self, msg):

        scan = np.array(msg.ranges, dtype=np.float32)

        # xử lý nan/inf
        scan = np.nan_to_num(
            scan,
            nan=1.0,
            posinf=1.0,
            neginf=0.0
        )

        # Nếu số tia khác 24
        if len(scan) != 24:
            self.get_logger().warn(
                f"Expected 24 rays, got {len(scan)}"
            )
            return

        scan = np.clip(scan, 0.0, 1.0)

        self.scan = scan.tolist()
        self.scan_ready = True

    # =====================================================

    def odom_callback(self, msg):

        if not self.scan_ready:
            return

        # -------------------------
        # Position
        # -------------------------
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y

        # -------------------------
        # Quaternion -> Yaw
        # -------------------------
        q = msg.pose.pose.orientation

        yaw = math.atan2(
            2.0 * (q.w * q.z + q.x * q.y),
            1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        )

        # -------------------------
        # Distance
        # -------------------------
        distance = math.sqrt(
            (self.goal_x - x) ** 2 +
            (self.goal_y - y) ** 2
        )

        distance_norm = distance / 10.0
        distance_norm = np.clip(distance_norm, 0.0, 1.0)

        # -------------------------
        # Goal Angle
        # -------------------------
        desired_yaw = math.atan2(
            self.goal_y - y,
            self.goal_x - x
        )

        angle = desired_yaw - yaw

        angle = math.atan2(
            math.sin(angle),
            math.cos(angle)
        )

        angle_norm = angle / math.pi

        # -------------------------
        # Linear velocity
        # -------------------------
        linear = msg.twist.twist.linear.x

        linear_norm = linear / 0.22
        linear_norm = np.clip(
            linear_norm,
            0.0,
            1.0
        )

        # -------------------------
        # 27-D RL State
        # -------------------------
        state = []

        state.extend(self.scan)

        state.append(float(distance_norm))
        state.append(float(angle_norm))
        state.append(float(linear_norm))

        state = np.array(state, dtype=np.float32)

        if np.isnan(state).any():
            self.get_logger().warn("NaN detected!")
            return

        msg_out = Float32MultiArray()
        msg_out.data = state.tolist()

        self.state_pub.publish(msg_out)

        # Debug mỗi 10 lần
        self.counter += 1

        if self.counter % 10 == 0:

            self.get_logger().info(
                f"Distance={distance_norm:.2f} | "
                f"Angle={angle_norm:.2f} | "
                f"V={linear_norm:.2f}"
            )


def main(args=None):

    rclpy.init(args=args)

    node = StateNode()

    try:
        rclpy.spin(node)

    except KeyboardInterrupt:
        pass

    node.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()