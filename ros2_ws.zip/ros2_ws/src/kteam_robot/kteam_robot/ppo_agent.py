#!/usr/bin/env python3

import math
import os

import numpy as np
import torch
import torch.nn as nn

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import Twist


class ActorCritic(nn.Module):
    def __init__(self, state_dim=27, action_dim=2):
        super().__init__()
        self.actor_fc = nn.Sequential(
            nn.Linear(state_dim, 128), nn.ReLU(),
            nn.Linear(128, 64), nn.ReLU()
        )
        self.actor_mu = nn.Sequential(
            nn.Linear(64, action_dim),
            nn.Tanh()
        )
        self.actor_log_std = nn.Parameter(torch.zeros(action_dim))

        # Chỉ để khớp checkpoint, không dùng lúc suy luận.
        self.critic = nn.Sequential(
            nn.Linear(state_dim, 128), nn.ReLU(),
            nn.Linear(128, 64), nn.ReLU(),
            nn.Linear(64, 1)
        )

    def act(self, state):
        f = self.actor_fc(state)
        mu = self.actor_mu(f)
        return torch.clamp(mu, -1.0, 1.0)


class PPOPotentialFieldNode(Node):
    def __init__(self):
        super().__init__("ppo_agent")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.model = ActorCritic(state_dim=27, action_dim=2).to(self.device)
        model_path = os.path.expanduser("~/NCKH/ppo_turtlebot3_epfinal_10000.pth")
        state_dict = torch.load(model_path, map_location=self.device, weights_only=True)
        self.model.load_state_dict(state_dict)
        self.model.eval()

        self.action_scale = torch.tensor([0.11, 1.0], device=self.device)
        self.action_bias = torch.tensor([0.11, 0.0], device=self.device)

        self.goal_radius = 0.15
        self.goal_reached = False

        # ---- Tham số potential field (CẦN TINH CHỈNH khi test thực tế) ----
        self.lidar_max_range = 3.5          # khớp lidar_max_range trong train_all.py
        self.repulsion_gain = 1.4           # độ mạnh của lực đẩy tối đa
        self.speed_floor_ratio = 0.35       # tốc độ tối thiểu (tỉ lệ) khi vật cản rất gần, KHÔNG bao giờ dừng hẳn/lùi
        self.control_lag_buffer = 0.04      # biên dự phòng thêm (m) cho quán tính/độ trễ điều khiển robot thật
        # góc của 24 tia Lidar, PHẢI khớp np.linspace(-pi/3, pi/3, 24) trong train_all.py
        self.ray_angles = np.linspace(-math.pi / 3, math.pi / 3, 24)

        # ---- Hình học THẬT của khung robot (thay cho giả định hình tròn 0.1m lúc train) ----
        self.half_length = 0.069            # 138mm / 2
        self.half_width = 0.089             # 178mm / 2
        # Với mỗi góc tia theta, khoảng cách từ TÂM tới MÉP khung chữ nhật:
        #   r(theta) = min(a/|cos(theta)|, b/|sin(theta)|)
        cos_t = np.cos(self.ray_angles)
        sin_t = np.sin(self.ray_angles)
        with np.errstate(divide="ignore"):
            r_front = self.half_length / np.abs(cos_t)
            r_side = np.where(np.abs(sin_t) > 1e-6, self.half_width / np.abs(sin_t), np.inf)
        self.footprint_clearance = np.minimum(r_front, r_side)  # (24,) mét, theo từng tia
        # Bán kính "ảnh hưởng" giờ tính theo TỪNG tia: mép khung + biên trễ + vùng cảnh báo sớm
        self.influence_margin = 0.35        # vùng cảnh báo sớm CHUNG cho mọi hướng, cộng thêm sau mép khung thật
        self.influence_radius_per_ray = self.footprint_clearance + self.control_lag_buffer + self.influence_margin

        self.pub = self.create_publisher(Twist, "/cmd_vel", 10)
        self.create_subscription(Float32MultiArray, "/rl_state", self.cb, 10)
        self.get_logger().info(f"PPO + Potential Field (rectangular footprint) Started (device={self.device})")

    def _repulsion(self, lidar_norm: np.ndarray):
        """Trả về (goc_day, he_so_giam_toc). Cả hai đều liên tục, không bậc thang.
        Dùng ĐÚNG khoảng cách còn lại tới MÉP khung chữ nhật (không phải tới tâm),
        theo từng góc tia riêng biệt, thay vì một bán kính tròn chung."""
        dists_m = lidar_norm * self.lidar_max_range

        # Khoảng cách còn lại sau khi trừ đi phần khung xe đã chiếm theo hướng đó
        clearance = dists_m - self.footprint_clearance          # (24,) - có thể âm nếu đã chạm
        min_clearance = float(np.min(clearance))

        mask = dists_m < self.influence_radius_per_ray
        if not np.any(mask):
            return 0.0, 1.0  # không có gì gần -> không can thiệp gì cả

        # Cường độ tăng dần (bậc 2 cho mượt), tính trên CLEARANCE thật (đã trừ khung xe)
        strength = np.zeros_like(dists_m)
        denom = self.influence_radius_per_ray - self.footprint_clearance  # = control_lag_buffer + influence_margin
        norm_gap = np.clip(clearance - self.control_lag_buffer, 0.0, None) / np.maximum(self.influence_margin, 1e-6)
        strength[mask] = (1.0 - np.clip(norm_gap[mask], 0.0, 1.0)) ** 2

        # Đẩy ra XA hướng của tia đó: tia ở góc dương (bên trái) -> đẩy sang phải (âm)
        angular_push = float(np.sum(-self.ray_angles * strength)) * self.repulsion_gain
        angular_push = float(np.clip(angular_push, -1.5, 1.5))

        # Giảm tốc mượt theo clearance nhỏ nhất còn lại, không bao giờ về 0 hẳn
        worst_norm_gap = float(np.clip((min_clearance - self.control_lag_buffer) / max(self.influence_margin, 1e-6), 0.0, 1.0))
        speed_scale = self.speed_floor_ratio + (1.0 - self.speed_floor_ratio) * worst_norm_gap
        return angular_push, float(np.clip(speed_scale, self.speed_floor_ratio, 1.0))

    def cb(self, msg):
        if self.goal_reached:
            self.pub.publish(Twist())
            return

        state = np.asarray(msg.data, dtype=np.float32)
        if len(state) == 28:
            state = state[:27]
        if len(state) != 27:
            self.get_logger().warn(f"Expected 27 states, got {len(state)}")
            return

        distance_m = float(state[24]) * 10.0
        if distance_m <= self.goal_radius:
            self.goal_reached = True
            self.pub.publish(Twist())
            self.get_logger().info(f"Đã tới đích! Distance={distance_m:.3f}m -> Dừng robot.")
            return

        with torch.no_grad():
            s = torch.from_numpy(state).float().unsqueeze(0).to(self.device)
            action = self.model.act(s).squeeze(0)
            real_action = action * self.action_scale + self.action_bias

        angular_ppo = float(real_action[1].cpu())
        linear_ppo = float(real_action[0].cpu())

        angular_push, speed_scale = self._repulsion(state[0:24])

        t = Twist()
        t.linear.x = linear_ppo * speed_scale
        t.angular.z = float(np.clip(angular_ppo + angular_push, -1.5, 1.5))
        self.pub.publish(t)


def main(args=None):
    rclpy.init(args=args)
    node = PPOPotentialFieldNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()