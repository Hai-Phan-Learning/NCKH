import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


class AvoidObstacle(Node):
   def __init__(self):
       super().__init__('avoid_obstacle')
       self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
       self.subscriber = self.create_subscription(LaserScan, '/scan', self.callback, 10)
       self.get_logger().info("Robot đang chạy chế độ tự tránh vật cản...")


   def callback(self, scan):
       front = min(min(scan.ranges[0:15] + scan.ranges[-15:]), 10.0)
       cmd = Twist()
       if front < 0.5:
           self.get_logger().info("Phát hiện vật cản! Quay trái...")
           cmd.angular.z = 0.5
       else:
           cmd.linear.x = 0.2
       self.publisher.publish(cmd)


def main():
   rclpy.init()
   node = AvoidObstacle()
   rclpy.spin(node)
   node.destroy_node()
   rclpy.shutdown()


if __name__ == '__main__':
   main()
