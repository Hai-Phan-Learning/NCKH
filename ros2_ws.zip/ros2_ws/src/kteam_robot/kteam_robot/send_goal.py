#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from nav2_msgs.action import NavigateToPose


class SendGoal(Node):

    def __init__(self):

        super().__init__("send_goal")

        self.client = ActionClient(
            self,
            NavigateToPose,
            "/navigate_to_pose"
        )

        self.get_logger().info("Waiting for NavigateToPose server...")

        while not self.client.wait_for_server(timeout_sec=1.0):
            self.get_logger().info("Waiting for NavigateToPose server...")

        self.get_logger().info("NavigateToPose server found!")

        self.send_goal()

    ####################################################

    def send_goal(self):

        goal_msg = NavigateToPose.Goal()

        goal_msg.pose.header.frame_id = "map"
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()

        # Goal position
        goal_msg.pose.pose.position.x = -4.5
        goal_msg.pose.pose.position.y = 0.0
        goal_msg.pose.pose.position.z = 0.0

        # Goal orientation
        yaw = 0.0

        goal_msg.pose.pose.orientation.x = 0.0
        goal_msg.pose.pose.orientation.y = 0.0
        goal_msg.pose.pose.orientation.z = math.sin(yaw / 2.0)
        goal_msg.pose.pose.orientation.w = math.cos(yaw / 2.0)

        self.get_logger().info(
            "Sending goal: (-4.5, 0.0)"
        )

        future = self.client.send_goal_async(
            goal_msg,
            feedback_callback=self.feedback_callback
        )

        future.add_done_callback(self.goal_response_callback)

    ####################################################

    def goal_response_callback(self, future):

        goal_handle = future.result()

        if goal_handle is None:
            self.get_logger().error("Failed to connect to action server.")
            rclpy.shutdown()
            return

        if not goal_handle.accepted:
            self.get_logger().error("Goal rejected.")
            rclpy.shutdown()
            return

        self.get_logger().info("Goal accepted.")

        result_future = goal_handle.get_result_async()

        result_future.add_done_callback(self.result_callback)

    ####################################################

    def feedback_callback(self, feedback_msg):

        feedback = feedback_msg.feedback

        self.get_logger().info(
            f"Distance remaining: {feedback.distance_remaining:.2f} m"
        )

    ####################################################

    def result_callback(self, future):

        result = future.result()

        if result.status == 4:
            self.get_logger().info("Goal reached successfully!")
        else:
            self.get_logger().warn(
                f"Navigation finished with status: {result.status}"
            )

        self.destroy_node()

        rclpy.shutdown()


########################################################

def main(args=None):

    rclpy.init(args=args)

    node = SendGoal()

    rclpy.spin(node)


if __name__ == "__main__":
    main()