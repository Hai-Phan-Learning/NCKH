import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


class MoveForwardNode(Node):
   def __init__(self):
       super().__init__('move_forward')
       self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)


       timer_period = 0.1  # 10 Hz
       self.timer = self.create_timer(timer_period, self.timer_callback)
       self.get_logger().info("Moving TurtleBot3 forward...")


   def timer_callback(self):
       msg = Twist()
       msg.linear.x = 0.1  # tốc độ tiến
       msg.angular.z = 0.0  # không quay
       self.publisher_.publish(msg)


def main(args=None):
   rclpy.init(args=args)
   node = MoveForwardNode()
   rclpy.spin(node)
   node.destroy_node()
   rclpy.shutdown()