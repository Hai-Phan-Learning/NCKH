#!/usr/bin/env python3
import math
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan

# ==========================================================
# THÔNG SỐ GIỐNG MÔI TRƯỜNG PPO
# ==========================================================
RL_MIN_ANGLE = -math.pi / 3.0          # -60°
RL_MAX_ANGLE = math.pi / 3.0           # +60°
RL_NUM_RAYS = 24
RL_MAX_RANGE = 3.5                     # giống lúc train
RL_ANGLE_INCREMENT = (RL_MAX_ANGLE - RL_MIN_ANGLE) / (RL_NUM_RAYS - 1)


class ScanFilter(Node):
    def __init__(self):
        super().__init__('scan_filter')
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )
        self.scan_pub = self.create_publisher(
            LaserScan,
            '/scan_rl',
            10
        )
        self._printed_debug_info = False
        self.get_logger().info("Scan Filter Started")

    # ==========================================================
    # Callback
    # ==========================================================
    def scan_callback(self, msg):
        num_points = len(msg.ranges)

        # In 1 lần duy nhất để xác nhận đúng convention của Lidar thật
        # (angle_min âm hay 0, angle_increment dương hay âm, bao nhiêu tia)
        if not self._printed_debug_info:
            self.get_logger().info(
                f"[SCAN INFO] num_points={num_points} "
                f"angle_min={math.degrees(msg.angle_min):.1f}deg "
                f"angle_max={math.degrees(msg.angle_max):.1f}deg "
                f"angle_increment={math.degrees(msg.angle_increment):.4f}deg "
                f"range_min={msg.range_min:.3f} range_max={msg.range_max:.3f}"
            )
            self._printed_debug_info = True

        lidar24 = []
        for i in range(RL_NUM_RAYS):
            ####################################################
            # Góc của tia đúng như PPO
            ####################################################
            angle = RL_MIN_ANGLE + i * RL_ANGLE_INCREMENT
            ####################################################
            # Chuyển góc -> index trong LaserScan
            # SỬA: dùng modulo (%) để "quấn vòng" quanh 360 độ,
            # thay vì clamp (max/min) như bản cũ. Clamp làm mọi
            # index âm (khi angle < msg.angle_min) bị dồn hết về
            # index 0 -> nhiều tia khác nhau lấy trùng 1 giá trị.
            # Modulo xử lý đúng vì LaserScan quét trọn 1 vòng tròn.
            ####################################################
            raw_index = (angle - msg.angle_min) / msg.angle_increment
            index = int(round(raw_index)) % num_points
            ####################################################
            # Lấy khoảng cách
            ####################################################
            r = msg.ranges[index]
            ####################################################
            # Xử lý inf / nan
            ####################################################
            if math.isinf(r) or math.isnan(r):
                r = RL_MAX_RANGE
            ####################################################
            # Giới hạn đúng môi trường train
            ####################################################
            r = min(max(r, msg.range_min), RL_MAX_RANGE)
            ####################################################
            # Normalize
            ####################################################
            lidar24.append(r / RL_MAX_RANGE)

        ########################################################
        # Publish
        ########################################################
        out = LaserScan()
        out.header = msg.header
        out.angle_min = RL_MIN_ANGLE
        out.angle_max = RL_MAX_ANGLE
        out.angle_increment = RL_ANGLE_INCREMENT
        out.range_min = 0.0
        out.range_max = 1.0
        out.ranges = lidar24
        out.intensities = []
        self.scan_pub.publish(out)

        ########################################################
        # Debug
        ########################################################
        print("\n========== PPO LIDAR ==========")
        print(np.round(np.array(lidar24), 3))
        print("================================\n")


def main(args=None):
    rclpy.init(args=args)
    node = ScanFilter()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()