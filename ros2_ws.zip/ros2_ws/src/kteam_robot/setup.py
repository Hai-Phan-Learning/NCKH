from setuptools import setup
from glob import glob
import os

package_name = 'kteam_robot'


setup(
   name=package_name,
   version='0.0.0',
   packages=[package_name],
       data_files=[
        ('share/ament_index/resource_index/packages',
         ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'),
         glob('launch/*.py')),
    ],          
   install_requires=['setuptools'],
   zip_safe=True,
   maintainer='Kteam robot',
   maintainer_email='robot@ekteam.com',
   description='Simple package to move TurtleBot3 forward from Kteam by K9',
   license='Kteam robot License 1.0',
   entry_points={
       'console_scripts': [
           'move_forward = kteam_robot.move_forward:main',
           'scan_filter = kteam_robot.scan_filter:main',
           'state_node = kteam_robot.state_node:main',
           'avoid = kteam_robot.avoid:main',
           'send_goal = kteam_robot.send_goal:main',
           'random_patrol = kteam_robot.random_patrol:main',
           'ppo_agent = kteam_robot.ppo_agent:main',
       ],
   },
)