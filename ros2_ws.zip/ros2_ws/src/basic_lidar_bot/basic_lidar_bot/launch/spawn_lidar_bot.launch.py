from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess
from ament_indepython.packages import get_package_share_directory
import os


def generate_launch_description():
   urdf_file = os.path.join(get_package_share_directory('basic_lidar_bot'), 'urdf', 'lidar_bot.urdf.xacro')


   return LaunchDescription([
       # Start Gazebo
       ExecuteProcess(
           cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_factory.so'],
           output='screen'),


       # Spawn robot in Gazebo
       Node(
           package='robot_state_publisher',
           executable='robot_state_publisher',
           name='robot_state_publisher',
           output='screen',
           arguments=[urdf_file]
       ),


       Node(
           package='gazebo_ros',
           executable='spawn_entity.py',
           arguments=['-file', urdf_file, '-entity', 'lidar_bot'],
           output='screen'
       )
   ])
