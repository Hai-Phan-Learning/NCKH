from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    return LaunchDescription([

        Node(
            package='kteam_robot',
            executable='scan_filter',
            name='scan_filter',
            output='screen'
        ),

        Node(
            package='kteam_robot',
            executable='state_node',
            name='state_node',
            output='screen'
        ),

        Node(
            package='kteam_robot',
            executable='ppo_agent',
            name='ppo_agent',
            output='screen'
        ),

    ])