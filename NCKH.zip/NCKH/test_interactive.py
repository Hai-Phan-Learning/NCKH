import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import math
import numpy as np
import torch
import torch.nn as nn
from torch.distributions import Normal
import matplotlib.pyplot as plt

# Thiết lập môi trường hiển thị UI
import matplotlib
matplotlib.use('TkAgg') # Bật chế độ tương tác giao diện đồ họa

# ==========================================
# 1. KHUNG XƯƠNG MẠNG ACTOR CẦN LOAD (Dán từ file tổng)
# ==========================================
class ActorCritic(nn.Module):
    def __init__(self, state_dim=27, action_dim=2):
        super(ActorCritic, self).__init__()
        self.actor_fc = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU()
        )
        self.actor_mu = nn.Sequential(
            nn.Linear(64, action_dim),
            nn.Tanh()
        )
        self.actor_log_std = nn.Parameter(torch.zeros(action_dim))
        self.critic = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

    def get_action_and_value(self, state, action=None):
        actor_features = self.actor_fc(state)
        mu = self.actor_mu(actor_features)
        std = self.actor_log_std.exp().expand_as(mu)
        dist = Normal(mu, std)
        if action is None:
            action = dist.sample()
        action = torch.clamp(action, -1.0, 1.0)
        return action, dist.log_prob(action).sum(dim=-1), dist.entropy().sum(dim=-1), self.critic(state)

# ==========================================
# 2. HÀM TÍNH TOÁN LIDAR ẢO THỜI GIAN THỰC (Inference Node Logic)
# ==========================================
def get_observation(robot_pose, v_prev, obstacles, goal_pos):
    rx, ry, rtheta = robot_pose
    lidar_max_range = 3.5
    obs_radius = 0.1
    x_min, x_max, y_min, y_max = -5.0, 5.0, -2.5, 2.5

    angles = np.linspace(-math.pi/3, math.pi/3, 24)
    lidar_dists = np.full(24, lidar_max_range)
    
    for i, angle_offset in enumerate(angles):
        ray_angle = rtheta + angle_offset
        dx = math.cos(ray_angle)
        dy = math.sin(ray_angle)
        min_dist = lidar_max_range
        
        if dx > 0: min_dist = min(min_dist, (x_max - rx) / dx)
        elif dx < 0: min_dist = min(min_dist, (x_min - rx) / dx)
        if dy > 0: min_dist = min(min_dist, (y_max - ry) / dy)
        elif dy < 0: min_dist = min(min_dist, (y_min - ry) / dy)
        
        for ox, oy in obstacles:
            fx = rx - ox
            fy = ry - oy
            a = dx*dx + dy*dy
            b = 2 * (fx*dx + fy*dy)
            c = (fx*fx + fy*fy) - obs_radius**2
            discriminant = b*b - 4*a*c
            if discriminant >= 0:
                t = (-b - math.sqrt(discriminant)) / (2*a)
                if 0 < t < min_dist:
                    min_dist = t
        lidar_dists[i] = min_dist

    lidar_norm = lidar_dists / lidar_max_range
    dist_to_goal = np.linalg.norm(np.array([rx, ry]) - goal_pos)
    distance_norm = dist_to_goal / 10.0
    
    target_angle = math.atan2(goal_pos[1] - ry, goal_pos[0] - rx)
    angle_diff = math.atan2(math.sin(target_angle - rtheta), math.cos(target_angle - rtheta))
    angle_norm = angle_diff / math.pi
    
    v_norm = v_prev / 0.22
    return np.concatenate([lidar_norm, [distance_norm, angle_norm, v_norm]], dtype=np.float32)

# ==========================================
# 3. GIAO DIỆN TƯƠNG TÁC VÀ MÔ PHỎNG QUỸ ĐẠO
# ==========================================
class InteractiveSim:
    def __init__(self, model_path):
        self.start_pos = np.array([4.5, 2.0])
        self.goal_pos = np.array([-4.5, 0.0])
        self.obstacles = []
        self.num_required_obs = 10
        
        # Load bộ não .pth
        self.device = torch.device("cpu")
        self.policy = ActorCritic(state_dim=27, action_dim=2)
        # Tự động tìm file pth mới nhất trong thư mục nếu có
        if os.path.exists(model_path):
            self.policy.load_state_dict(torch.load(model_path, map_location=self.device))
            print(f"-> Đã load thành công bộ não: {model_path}")
        else:
            print(f"❌ KHÔNG tìm thấy file: {model_path}! Hãy kiểm tra lại tên file.")
            return
        self.policy.eval()

        # Cấu hình Scale Hành động
        self.action_scale = torch.tensor([0.11, 1.0])
        self.action_bias = torch.tensor([0.11, 0.0])

        # Thiết lập đồ thị hiển thị map
        self.fig, self.ax = plt.subplots(figsize=(12, 7))
        self.setup_map()
        
        # Đăng ký sự kiện click chuột
        self.cid = self.fig.canvas.mpl_connect('button_press_event', self.on_click)
        plt.show()

    def setup_map(self):
        self.ax.clear()
        self.ax.set_xlim(-5.5, 5.5)
        self.ax.set_ylim(-3.0, 3.0)
        # Vẽ tường bao bản đồ 10x5m
        self.ax.plot([-5, 5, 5, -5, -5], [-2.5, -2.5, 2.5, 2.5, -2.5], 'k-', linewidth=3, label='Wall')
        # Vẽ điểm xuất phát và đích
        self.ax.plot(self.start_pos[0], self.start_pos[1], 'go', markersize=12, label='Start (4.5, 2.0)')
        self.ax.plot(self.goal_pos[0], self.goal_pos[1], 'ro', markersize=12, label='Goal (-4.5, 0.0)')
        
        self.ax.set_title(f"Click chuột để đặt 10 vật cản ({len(self.obstacles)}/{self.num_required_obs})", fontsize=14, fontweight='bold')
        self.ax.set_xlabel("X (meters)")
        self.ax.set_ylabel("Y (meters)")
        self.ax.grid(True, linestyle='--', alpha=0.5)
        self.ax.legend(loc='upper right')
        self.fig.canvas.draw()

    def on_click(self, event):
        # Kiểm tra xem có click hợp lệ trong map không
        if event.xdata is None or event.ydata is None: return
        if len(self.obstacles) >= self.num_required_obs: return

        # Lưu tọa độ vật cản mới click
        pos = np.array([event.xdata, event.ydata])
        self.obstacles.append(pos)
        
        # Vẽ vật cản hình trụ (Đường kính 20cm -> Bán kính 0.1m)
        circle = plt.Circle((pos[0], pos[1]), 0.1, color='gray', alpha=0.8)
        self.ax.add_patch(circle)
        self.ax.set_title(f"Click chuột để đặt 10 vật cản ({len(self.obstacles)}/{self.num_required_obs})", fontsize=14, fontweight='bold')
        self.fig.canvas.draw()

        # Khi đã kích đủ 10 điểm vật cản, bắt đầu chạy mô phỏng
        if len(self.obstacles) == self.num_required_obs:
            self.fig.canvas.mpl_disconnect(self.cid) # Tắt sự kiện click
            self.ax.set_title("Đang chạy mô phỏng quỹ đạo thời gian thực...", color='blue', fontsize=14, fontweight='bold')
            self.fig.canvas.draw()
            self.run_simulation()

    def run_simulation(self):
        # Khởi tạo trạng thái ban đầu của robot giống hệt custom_env
        dx = self.goal_pos[0] - self.start_pos[0]
        dy = self.goal_pos[1] - self.start_pos[1]
        init_theta = math.atan2(dy, dx)
        
        robot_pose = np.array([self.start_pos[0], self.start_pos[1], init_theta])
        v_prev = 0.0
        dt = 0.1
        
        trajectory_x = [robot_pose[0]]
        trajectory_y = [robot_pose[1]]
        
        max_steps = 600
        reached_goal = False
        crashed = False

        for step in range(max_steps):
            # 1. Tính toán vector Lidar và Goal trạng thái (27 phần tử)
            state = get_observation(robot_pose, v_prev, self.obstacles, self.goal_pos)
            
            # 2. Đẩy qua mạng Actor suy luận
            with torch.no_grad():
                state_tensor = torch.FloatTensor(state).unsqueeze(0)
                action, _, _, _ = self.policy.get_action_and_value(state_tensor)
                # Giải scale ra vận tốc vật lý thực
                real_action = action * self.action_scale + self.action_bias
                # v, w = real_action[0].item(), real_action[1].item()
                # Thêm .flatten() hoặc dùng .squeeze() để đưa về mảng 1 chiều trước khi lấy item
                v = real_action.flatten()[0].item()
                w = real_action.flatten()[1].item()
            # 3. Cập nhật động học xe vi sai
            robot_pose[0] += v * math.cos(robot_pose[2]) * dt
            robot_pose[1] += v * math.sin(robot_pose[2]) * dt
            robot_pose[2] += w * dt
            robot_pose[2] = math.atan2(math.sin(robot_pose[2]), math.cos(robot_pose[2]))
            
            v_prev = v
            
            # Lưu tọa độ để vẽ line
            trajectory_x.append(robot_pose[0])
            trajectory_y.append(robot_pose[1])
            
            # --- Kiểm tra va chạm hoặc tới đích thực tế ---
            dist_to_goal = np.linalg.norm(robot_pose[:2] - self.goal_pos)
            if dist_to_goal <= 0.15:
                reached_goal = True
                break
                
            # Kiểm tra đâm tường hoặc đâm 10 hình trụ
            if robot_pose[0] < -5.0 or robot_pose[0] > 5.0 or robot_pose[1] < -2.5 or robot_pose[1] > 2.5:
                crashed = True
                break
            for ox, oy in self.obstacles:
                if np.linalg.norm(robot_pose[:2] - np.array([ox, oy])) <= (0.1 + 0.1): # Bán kính xe + Bán kính vật cản
                    crashed = True
                    break

            # Vẽ động quỹ đạo từng bước lên màn hình
            self.ax.plot(trajectory_x[-2:], trajectory_y[-2:], color='blue', linewidth=2)
            self.fig.canvas.draw()
            plt.pause(0.01) # Tạo hiệu ứng xe đang chạy thời gian thực

        # Kết luận hiển thị kết quả cuối cùng
        if reached_goal:
            self.ax.set_title(f"THÀNH CÔNG! Đã tới đích an toàn sau {step} bước.", color='green', fontsize=14, fontweight='bold')
        elif crashed:
            self.ax.plot(robot_pose[0], robot_pose[1], 'x', color='darkred', markersize=15, markeredgewidth=3)
            self.ax.set_title(f"THẤT BẠI! Robot đã va chạm tại bước thứ {step}.", color='red', fontsize=14, fontweight='bold')
        else:
            self.ax.set_title(f"HẾT THỜI GIAN! Xe chạy quá {max_steps} bước (Kẹt tuần hoàn).", color='orange', fontsize=14, fontweight='bold')
            
        self.fig.canvas.draw()

if __name__ == '__main__':
    # Hãy sửa đường dẫn bên dưới đúng với tên file .pth mới nhất của bạn trong thư mục train_results
    MODEL_PATH = "train_results/ppo_turtlebot3_epfinal_10000.pth" 
    sim = InteractiveSim(MODEL_PATH)