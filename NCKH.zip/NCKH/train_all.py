# LiDAR-SLAM Based Autonomous Navigation and Trajectory Planning in Dynamic Environments via Custom Deep Reinforcement Learning
# Nhat Huy Dao 
# ------------------------
# PART 1: IMPORT THƯ VIỆN |
# ------------------------ 
import os
import math
import time
import numpy as np
import gymnasium as gym
from gymnasium import spaces

import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal

import matplotlib
matplotlib.use('Agg') 
import matplotlib.pyplot as plt

import os
# fix lỗi OpenMP trên Windows
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

# --------------------------------------------
# PART 2: ĐỊNH NGHĨA MÔI TRƯỜNG (custom_env)  |
# --------------------------------------------
class TurtleBot3ContinuousEnv(gym.Env):
    """
    Môi trường Custom RL cho TurtleBot3 (Không gian liên tục).
    - Map: 10x5m (x: -5 đến 5, y: -2.5 đến 2.5)
    - Trạng thái (27): 24 tia Lidar, distance_norm, angle_norm, v_prev
    - Hành động (2): v (0.0 -> 0.22 m/s), w (-1.0 -> 1.0 rad/s)
    """
    
    def __init__(self):
        super(TurtleBot3ContinuousEnv, self).__init__()
        
        # --- Thông số Robot và Bản đồ ---
        self.dt = 0.1 # Thời gian mô phỏng mỗi bước (10Hz)
        self.robot_radius = 0.1 # Bán kính xe (10cm = 20x20cm)
        self.obs_radius = 0.1 # Bán kính vật cản (10cm = đường kính 20cm)
        self.lidar_max_range = 3.5 # Tầm nhìn tối đa của Lidar (3.5m)
        self.num_obstacles = 10
        
        # Tọa độ giới hạn tường bao
        self.x_min, self.x_max = -5.0, 5.0
        self.y_min, self.y_max = -2.5, 2.5
        
        # Vị trí cố định Start và Goal
        self.start_pos = np.array([4.5, 2.0])
        self.goal_pos = np.array([-4.5, 0.0])
        self.goal_radius = 0.15 # Khoảng cách chấp nhận là tới đích
        
        # --- Cấu hình Không gian Hành động (Action Space) ---
        # Action 0: v (m/s) -> [0.0, 0.22]
        # Action 1: w (rad/s) -> [-1.0, 1.0]
        self.action_space = spaces.Box(
            low=np.array([0.0, -1.0], dtype=np.float32),
            high=np.array([0.22, 1.0], dtype=np.float32),
            dtype=np.float32
        )
        
        # --- Cấu hình Không gian Trạng thái (Observation Space) ---
        # 27 phần tử, đều được chuẩn hóa về dải [-1.0, 1.0] hoặc [0.0, 1.0]
        self.observation_space = spaces.Box(
            low=-np.ones(27, dtype=np.float32),
            high=np.ones(27, dtype=np.float32),
            dtype=np.float32
        )
        
        # Biến trạng thái nội bộ
        self.robot_pose = np.zeros(3) # [x, y, theta]
        self.obstacles = []
        self.v_prev = 0.0
        self.distance_prev = 0.0
        
    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        
        # 1. Đặt lại vị trí Robot và hướng (hướng về phía Goal ban đầu)
        dx = self.goal_pos[0] - self.start_pos[0]
        dy = self.goal_pos[1] - self.start_pos[1]
        init_theta = math.atan2(dy, dx)
        self.robot_pose = np.array([self.start_pos[0], self.start_pos[1], init_theta])
        self.v_prev = 0.0
        self.distance_prev = np.linalg.norm(self.start_pos - self.goal_pos)
        
        # 2. Sinh ngẫu nhiên vị trí 10 vật cản (không đè lên Start và Goal)
        self.obstacles = []
        while len(self.obstacles) < self.num_obstacles:
            # Random trong khoảng map (cách tường 0.2)
            ox = self.np_random.uniform(self.x_min + 0.2, self.x_max - 0.2)
            oy = self.np_random.uniform(self.y_min + 0.2, self.y_max - 0.2)
            pt = np.array([ox, oy])
            
            # Kiểm tra khoảng cách an toàn với Start, Goal và các vật cản khác
            dist_to_start = np.linalg.norm(pt - self.start_pos)
            dist_to_goal = np.linalg.norm(pt - self.goal_pos)
            
            if dist_to_start > 0.6 and dist_to_goal > 0.6:
                self.obstacles.append(pt)
                
        # 3. Lấy trạng thái đầu tiên
        obs = self._get_observation()
        return obs, {}
        
    def step(self, action):
        v, w = action[0], action[1]
        
        # 1. Cập nhật động học (Kinematics) của xe vi sai
        self.robot_pose[0] += v * math.cos(self.robot_pose[2]) * self.dt
        self.robot_pose[1] += v * math.sin(self.robot_pose[2]) * self.dt
        self.robot_pose[2] += w * self.dt
        
        # Ép góc theta về khoảng [-pi, pi]
        self.robot_pose[2] = math.atan2(math.sin(self.robot_pose[2]), math.cos(self.robot_pose[2]))
        
        # Lấy trạng thái mới
        obs = self._get_observation()
        
        # Các thông số từ hàm _get_observation để tính Reward
        lidar_scans = obs[0:24] * self.lidar_max_range # Giải chuẩn hóa để tính khoảng cách thực
        distance_curr = obs[24] * 10.0 # Giải chuẩn hóa (Map dài max cỡ 10m)
        angle_norm = obs[25] # Đã nằm trong [-1, 1] đại diện cho [-pi, pi]
        
        reward = 0
        terminated = False
        
        # 2. Kiểm tra điều kiện kết thúc (Va chạm tường hoặc vật cản)
        min_lidar_dist = np.min(lidar_scans)
        # Nếu xe ra ngoài map
        out_of_bounds = (self.robot_pose[0] < self.x_min or self.robot_pose[0] > self.x_max or 
                         self.robot_pose[1] < self.y_min or self.robot_pose[1] > self.y_max)
                         
        if min_lidar_dist <= (self.robot_radius + 0.02) or out_of_bounds:
            reward = -200.0
            terminated = True
            
        # 3. Kiểm tra điều kiện tới đích (Goal)
        elif distance_curr <= self.goal_radius:
            reward = 300.0
            terminated = True
            
        # 4. Tính toán phần thưởng từng bước (Step Reward) cho PPO
        else:
            # (distance_prev - distance_curr) dương là tiến gần goal, âm là đi xa goal
            reward_dist = (self.distance_prev - distance_curr) * 150.0 
            reward_angle = -1.0 * abs(angle_norm) # Phạt nếu lệch hướng
            reward_speed = 2.0 * v # Khuyến khích chạy nhanh
            reward_time_penalty = -0.2 # Phạt thời gian để khỏi đứng yên
            
            reward = reward_dist + reward_angle + reward_speed + reward_time_penalty
            
        # Cập nhật biến cho bước tiếp theo
        self.distance_prev = distance_curr
        self.v_prev = v
        
        return obs, reward, terminated, False, {}
        
    def _get_observation(self):
        """Tính toán và đóng gói 27 phần tử trạng thái"""
        rx, ry, rtheta = self.robot_pose
        
        # --- 1. Tính toán 24 tia Lidar ---
        angles = np.linspace(-math.pi/3, math.pi/3, 24) # -60 độ đến +60 độ
        lidar_dists = np.full(24, self.lidar_max_range)
        
        for i, angle_offset in enumerate(angles):
            ray_angle = rtheta + angle_offset
            dx = math.cos(ray_angle)
            dy = math.sin(ray_angle)
            
            min_dist = self.lidar_max_range
            
            # Raycast với 4 bức tường
            if dx > 0: min_dist = min(min_dist, (self.x_max - rx) / dx)
            elif dx < 0: min_dist = min(min_dist, (self.x_min - rx) / dx)
            if dy > 0: min_dist = min(min_dist, (self.y_max - ry) / dy)
            elif dy < 0: min_dist = min(min_dist, (self.y_min - ry) / dy)
            
            # Raycast với 10 vật cản hình trụ
            for ox, oy in self.obstacles:
                # Phương trình bậc 2 tìm giao điểm tia và đường tròn
                fx = rx - ox
                fy = ry - oy
                a = dx*dx + dy*dy
                b = 2 * (fx*dx + fy*dy)
                c = (fx*fx + fy*fy) - self.obs_radius**2
                
                discriminant = b*b - 4*a*c
                if discriminant >= 0:
                    t = (-b - math.sqrt(discriminant)) / (2*a)
                    if 0 < t < min_dist:
                        min_dist = t
                        
            lidar_dists[i] = min_dist
            
        # Chuẩn hóa Lidar [0, 1]
        lidar_norm = lidar_dists / self.lidar_max_range
        
        # --- 2. Tính toán distance_norm ---
        dist_to_goal = np.linalg.norm(np.array([rx, ry]) - self.goal_pos)
        distance_norm = dist_to_goal / 10.0 # Giả định max khoang cach la 10m
        
        # --- 3. Tính toán angle_norm ---
        target_angle = math.atan2(self.goal_pos[1] - ry, self.goal_pos[0] - rx)
        angle_diff = target_angle - rtheta
        # Đưa về đoạn [-pi, pi]
        angle_diff = math.atan2(math.sin(angle_diff), math.cos(angle_diff))
        angle_norm = angle_diff / math.pi # Nằm trong [-1, 1]
        
        # --- 4. v_prev norm ---
        v_norm = self.v_prev / 0.22 # Nằm trong [0, 1]
        
        # Đóng gói mảng 27 phần tử
        obs = np.concatenate([lidar_norm, [distance_norm, angle_norm, v_norm]], dtype=np.float32)
        return obs

# ---------------------------------------
# PART 3: KIẾN TRÚC MẠNG PPO (rl_agent)  |
# ---------------------------------------

# 3.1. BỘ NHỚ LƯU TRỮ TRẢI NGHIỆM (PPO BUFFER)

class PPOBuffer:
    def __init__(self):
        self.states = []
        self.actions = []
        self.log_probs = []
        self.rewards = []
        self.values = []
        self.dones = []

    def clear(self):
        self.states.clear()
        self.actions.clear()
        self.log_probs.clear()
        self.rewards.clear()
        self.values.clear()
        self.dones.clear()


# 3.2. KIẾN TRÚC MẠNG ACTOR-CRITIC
class ActorCritic(nn.Module):
    def __init__(self, state_dim=27, action_dim=2):
        super(ActorCritic, self).__init__()
        
        # Mạng Actor: Quyết định hành động
        self.actor_fc = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU()
        )
        self.actor_mu = nn.Sequential(
            nn.Linear(64, action_dim),
            nn.Tanh() # Ép đầu ra về khoảng [-1, 1]
        )
        # SỬA LỖI: Khai báo Log Std dạng vector 1D độc lập cho action_dim
        self.actor_log_std = nn.Parameter(torch.zeros(action_dim))
        
        # Mạng Critic: Đánh giá trạng thái V(s)
        self.critic = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

    # SỬA LỖI: Bổ sung hàm forward tiêu chuẩn cho PyTorch
    def forward(self, state):
        actor_features = self.actor_fc(state)
        mu = self.actor_mu(actor_features)
        value = self.critic(state)
        return mu, value

    def get_action_and_value(self, state, action=None):
        # 1. Tính toán giá trị V(s) từ Critic
        value = self.critic(state)
        
        # 2. Tính toán phân phối hành động từ Actor
        actor_features = self.actor_fc(state)
        mu = self.actor_mu(actor_features)
        
        # SỬA LỖI: Exp log_std chuẩn kích thước batch tự động
        std = self.actor_log_std.exp().expand_as(mu)
        
        dist = Normal(mu, std)
        
        # 3. Lấy mẫu hành động
        if action is None:
            action = dist.sample()
            
        # 4. Ép action về giới hạn [-1, 1] để tránh lỗi bùng nổ
        action = torch.clamp(action, -1.0, 1.0)
        
        return action, dist.log_prob(action).sum(dim=-1), dist.entropy().sum(dim=-1), value

# 3.3. THUẬT TOÁN PPO VÀ TRỰC QUAN HÓA

class PPOAgent:
    def __init__(self, state_dim=27, action_dim=2, lr_actor=3e-4, lr_critic=1e-3, gamma=0.99, K_epochs=10, eps_clip=0.2):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"[PPO Agent] Khởi tạo thành công. Device: {self.device}")
        
        self.policy = ActorCritic(state_dim, action_dim).to(self.device)
        self.optimizer = optim.Adam([
            {'params': self.policy.actor_fc.parameters(), 'lr': lr_actor},
            {'params': self.policy.actor_mu.parameters(), 'lr': lr_actor},
            {'params': self.policy.actor_log_std, 'lr': lr_actor},
            {'params': self.policy.critic.parameters(), 'lr': lr_critic}
        ])
        
        self.buffer = PPOBuffer()
        
        self.gamma = gamma
        self.eps_clip = eps_clip
        self.K_epochs = K_epochs
        
        # Cấu hình Scale Hành động cho Robot (v: 0->0.22, w: -1->1)
        self.action_scale = torch.tensor([0.11, 1.0]).to(self.device)
        self.action_bias = torch.tensor([0.11, 0.0]).to(self.device)
        
        # --- Biến lưu trữ phục vụ vẽ đồ thị khoa học ---
        self.history_rewards = []
        self.history_actor_loss = []
        self.history_critic_loss = []
        
        # Tạo thư mục lưu kết quả
        self.save_dir = "train_results"
        os.makedirs(self.save_dir, exist_ok=True)

    def select_action(self, state):
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            action, log_prob, _, value = self.policy.get_action_and_value(state_tensor)
            
            self.buffer.states.append(state_tensor)
            self.buffer.actions.append(action)
            self.buffer.log_probs.append(log_prob)
            self.buffer.values.append(value)
            
            # Giải mã hành động từ [-1, 1] sang dải vật lý thực (v, w)
            real_action = action * self.action_scale + self.action_bias
            
            return real_action.cpu().numpy().flatten()

    def update(self):
        # Chuyển đổi list sang tensor
        old_states = torch.squeeze(torch.stack(self.buffer.states, dim=0)).detach().to(self.device)
        old_actions = torch.squeeze(torch.stack(self.buffer.actions, dim=0)).detach().to(self.device)
        old_logprobs = torch.squeeze(torch.stack(self.buffer.log_probs, dim=0)).detach().to(self.device)
        old_values = torch.squeeze(torch.stack(self.buffer.values, dim=0)).detach().to(self.device)
        
        rewards = self.buffer.rewards
        dones = self.buffer.dones
        
        # Tính toán Gt (Returns) và Lợi thế (Advantages)
        returns = []
        discounted_reward = 0
        for reward, is_terminal in zip(reversed(rewards), reversed(dones)):
            if is_terminal:
                discounted_reward = 0
            discounted_reward = reward + (self.gamma * discounted_reward)
            returns.insert(0, discounted_reward)
            
        returns = torch.tensor(returns, dtype=torch.float32).to(self.device)
        returns = (returns - returns.mean()) / (returns.std() + 1e-7) # Chuẩn hóa
        
        advantages = returns - old_values
        
        actor_loss_epoch = 0
        critic_loss_epoch = 0
        
        # Optimize K_epochs lần trên cùng một batch dữ liệu
        for _ in range(self.K_epochs):
            _, logprobs, dist_entropy, state_values = self.policy.get_action_and_value(old_states, old_actions)
            state_values = torch.squeeze(state_values)
            
            # Tính tỷ lệ (ratio) pi_theta / pi_theta_old
            ratios = torch.exp(logprobs - old_logprobs)
            
            # Surrogate Loss (Clipped)
            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
            
            actor_loss = -torch.min(surr1, surr2).mean()
            critic_loss = nn.MSELoss()(state_values, returns)
            
            # Tổng Loss
            loss = actor_loss + 0.5 * critic_loss - 0.01 * dist_entropy.mean()
            
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
            actor_loss_epoch += actor_loss.item()
            critic_loss_epoch += critic_loss.item()
            
        self.buffer.clear()
        
        # Lưu lịch sử Loss để vẽ đồ thị
        self.history_actor_loss.append(actor_loss_epoch / self.K_epochs)
        self.history_critic_loss.append(critic_loss_epoch / self.K_epochs)

    def log_episode_reward(self, total_reward):
        """Gọi hàm này sau khi kết thúc 1 episode để lưu lại tổng điểm"""
        self.history_rewards.append(total_reward)

    def save_models_and_plots(self, episode_num="early_stop"):
        """Tự động lưu mô hình và xuất các đồ thị chuẩn khoa học"""
        print(f"\n[LƯU TRỮ] Đang xuất dữ liệu tại tập {episode_num}...")
        
        # 1. Lưu trọng số mô hình
        model_path = os.path.join(self.save_dir, f'ppo_turtlebot3_{episode_num}.pth')
        torch.save(self.policy.state_dict(), model_path)
        print(f"-> Đã lưu mô hình tại: {model_path}")
        
        # 2. Thiết lập style chuẩn báo cáo IEEE cho biểu đồ
        plt.style.use('seaborn-v0_8-whitegrid')
        fig = plt.figure(figsize=(15, 10))
        
        # Đồ thị 1: Tổng phần thưởng (Rewards)
        ax1 = fig.add_subplot(2, 1, 1)
        ax1.plot(self.history_rewards, color='#1f77b4', alpha=0.6, label='Raw Reward')
        # Thêm đường trung bình trượt (Moving Average) cho mượt
        if len(self.history_rewards) >= 10:
            moving_avg = np.convolve(self.history_rewards, np.ones(10)/10, mode='valid')
            ax1.plot(range(9, len(self.history_rewards)), moving_avg, color='#d62728', linewidth=2, label='10-Episode Moving Avg')
        ax1.set_title('Episode Rewards Over Time', fontsize=14, fontweight='bold')
        ax1.set_xlabel('Episodes', fontsize=12)
        ax1.set_ylabel('Total Reward', fontsize=12)
        ax1.legend()
        
        # Đồ thị 2: Loss của Actor và Critic
        ax2 = fig.add_subplot(2, 1, 2)
        ax2.plot(self.history_actor_loss, color='#2ca02c', label='Actor Loss (Policy)')
        ax2.plot(self.history_critic_loss, color='#ff7f0e', label='Critic Loss (Value)')
        ax2.set_title('Training Losses', fontsize=14, fontweight='bold')
        ax2.set_xlabel('Update Steps', fontsize=12)
        ax2.set_ylabel('Loss Value', fontsize=12)
        ax2.legend()
        
        plt.tight_layout()
        plot_path = os.path.join(self.save_dir, f'training_metrics_{episode_num}.png')
        plt.savefig(plot_path, dpi=300) # Xuất ảnh 300 DPI độ phân giải cao cho báo cáo
        plt.close()
        
        print(f"-> Đã xuất đồ thị tại: {plot_path}")

# --------------------------------------------
# PART 4: VÒNG LẶP HUẤN LUYỆN CHÍNH (train)   |
# --------------------------------------------

def train():

    # 1. CẤU HÌNH SIÊU THAM SỐ (HYPERPARAMETERS)

    max_episodes = 5000           # Tổng số tập huấn luyện tối đa
    max_steps_per_episode = 500   # Số bước đi tối đa trong 1 tập (tránh xe chạy vòng tròn mãi)
    update_timestep = 2048        # Số bước tích lũy trước khi cho mạng PPO học 1 lần
    save_model_freq = 500         #5 Lưu file checkpoint mỗi 500 tập
    
    # Khởi tạo Môi trường và Agent
    env = TurtleBot3ContinuousEnv()
    
    # Lấy kích thước state và action từ cấu hình của env
    state_dim = env.observation_space.shape[0] # 27
    action_dim = env.action_space.shape[0]     # 2
    
    agent = PPOAgent(state_dim, action_dim)
    
    # 4.2. VÒNG LẶP HUẤN LUYỆN CHÍNH

    time_step = 0
    print("\n[BẮT ĐẦU TRÌNH HUẤN LUYỆN PPO - CONTINUOUS]")
    print("-" * 50)
    
    try:
        for episode in range(1, max_episodes + 1):
            state, _ = env.reset()
            current_ep_reward = 0
            
            for t in range(max_steps_per_episode):
                # Chọn hành động từ Agent
                action = agent.select_action(state)
                
                # Thực thi hành động trong môi trường
                next_state, reward, done, truncated, _ = env.step(action)
                
                # Lưu reward và trạng thái done vào bộ nhớ của agent
                agent.buffer.rewards.append(reward)
                agent.buffer.dones.append(done)
                
                state = next_state
                current_ep_reward += reward
                time_step += 1
                
                # Khi tích lũy đủ số bước, tiến hành cập nhật mạng (Học)
                if time_step % update_timestep == 0:
                    print(f"  -> [Học tập] Đang cập nhật trọng số tại bước {time_step}...")
                    agent.update()
                
                # Kết thúc tập nếu đâm hoặc tới đích
                if done:
                    break
            
            # Ghi log điểm số của tập này
            agent.log_episode_reward(current_ep_reward)
            
            # Hiển thị tiến độ ra màn hình
            if episode % 10 == 0:
                print(f"Tập: {episode}/{max_episodes} \t Số bước: {t} \t Điểm tổng (Reward): {current_ep_reward:.2f}")
            
            # Lưu checkpoint định kỳ
            if episode % save_model_freq == 0:
                agent.save_models_and_plots(episode_num=str(episode))
                
        print("\n[HOÀN THÀNH] Đã huấn luyện xong toàn bộ số tập dự kiến!")


    # 4.3. KỸ THUẬT EARLY STOP
  
    except KeyboardInterrupt:
        print("\n" + "="*50)
        print("⚠️ [CẢNH BÁO] Người dùng nhấn Ctrl+C ngắt ngang quá trình!")
        print("Hệ thống đang tiến hành lưu giữ liệu an toàn...")
        print("="*50)
        
    finally:
        # Đoạn code này LUÔN ĐƯỢC CHẠY khi kết thúc hoặc khi bị ngắt
        print("\n[KẾT THÚC] Đang xuất toàn bộ mô hình và đồ thị cuối cùng...")
        # Lấy số episode hiện tại để đặt tên file
        final_ep = episode if 'episode' in locals() else 0
        agent.save_models_and_plots(episode_num=f"final_ep{final_ep}")
        print("Toàn bộ dữ liệu huấn luyện đã được lưu an toàn. Chúc bạn viết báo cáo tốt!")

if __name__ == '__main__':
    # Lưu ý: Cần tắt các cửa sổ phụ hoặc cấu hình matplotlib.use('Agg') ở rl_agent để không crash
    train()