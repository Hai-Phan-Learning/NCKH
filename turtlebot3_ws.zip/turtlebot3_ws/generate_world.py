#!/usr/bin/env python3
"""
CHẤM ĐIỂM VẬT CẢN TRÊN BẢN ĐỒ TRỐNG -> SINH RA WORLD GAZEBO

Cách dùng:
  1. Chạy: python3 pick_obstacles_map.py
  2. Một cửa sổ bản đồ trống hiện ra (trục x/y theo đúng đơn vị mét của map).
     - Chấm xanh lá  = Start
     - Chấm đỏ       = Goal
  3. Click chuột trái  -> đặt 1 vật cản tại vị trí đó.
     Nhấn phím 'z'     -> xoá vật cản vừa đặt (undo).
     Nhấn phím 'c'     -> xoá hết, làm lại từ đầu.
  4. Đóng cửa sổ (hoặc nhấn 'q') -> script tự động ghi các vật cản
     đó vào file world .sdf, ở đúng toạ độ bạn đã chấm.

Yêu cầu: pip install matplotlib
"""

import math
import itertools
import matplotlib.pyplot as plt

# ==========================================================
# CONFIG
# ==========================================================

WORLD_FILE = "/home/hai/Gazebo/My_first_world.sdf"

NUM_OBSTACLES = 15   # chấm đủ số này thì tự đóng cửa sổ và ghi vào world

RADIUS = 0.10
HEIGHT = 0.30

MIN_DISTANCE = 0.30   # khoảng cách tối thiểu giữa 2 vật cản

X_MIN, X_MAX = -5.0, 5.0
Y_MIN, Y_MAX = -2.0, 3.0

START = (4.5, 2.0)
GOAL = (-4.5, 0.0)

START_SAFE = 0.80
GOAL_SAFE = 0.80

COLOR_CYCLE = [
    "Red", "Blue", "Green", "Yellow", "Orange",
    "Purple", "Cyan", "Black", "DarkGrey", "White",
]

# ==========================================================
# Kiểm tra vị trí hợp lệ
# ==========================================================

def valid_position(x, y, positions):
    if x < X_MIN or x > X_MAX or y < Y_MIN or y > Y_MAX:
        return False, "Ngoài phạm vi map"
    if math.hypot(x - START[0], y - START[1]) < START_SAFE:
        return False, "Quá gần Start"
    if math.hypot(x - GOAL[0], y - GOAL[1]) < GOAL_SAFE:
        return False, "Quá gần Goal"
    for px, py in positions:
        if math.hypot(x - px, y - py) < MIN_DISTANCE:
            return False, "Quá gần vật cản khác"
    return True, ""


# ==========================================================
# GIAO DIỆN CHẤM ĐIỂM
# ==========================================================

positions = []
markers = []  # lưu các object matplotlib để có thể xoá khi undo

fig, ax = plt.subplots(figsize=(9, 6))
ax.set_xlim(X_MIN, X_MAX)
ax.set_ylim(Y_MIN, Y_MAX)
ax.set_aspect("equal")
ax.grid(True, linestyle="--", alpha=0.4)
ax.set_xlabel("x (m)")
ax.set_ylabel("y (m)")
ax.set_title(
    f"Click = đặt vật cản (đủ {NUM_OBSTACLES} sẽ tự lưu)   |   'z' = undo   |   'c' = xoá hết   |   'q'/đóng cửa sổ = lưu sớm"
)

ax.plot(*START, "go", markersize=14, label="Start")
ax.plot(*GOAL, "ro", markersize=14, label="Goal")
ax.add_patch(plt.Circle(START, START_SAFE, color="green", alpha=0.1))
ax.add_patch(plt.Circle(GOAL, GOAL_SAFE, color="red", alpha=0.1))
ax.legend(loc="upper right")

status_text = ax.text(
    0.02, 0.02, "", transform=ax.transAxes, fontsize=9, color="red"
)


def redraw_status(msg=""):
    status_text.set_text(msg)
    fig.canvas.draw_idle()


def on_click(event):
    if event.inaxes != ax:
        return
    if event.button != 1:  # chỉ nhận click chuột trái
        return

    if len(positions) >= NUM_OBSTACLES:
        return  # đã đủ số lượng, không nhận thêm click

    x, y = event.xdata, event.ydata
    ok, reason = valid_position(x, y, positions)

    if not ok:
        redraw_status(f"Không đặt được: {reason} (x={x:.2f}, y={y:.2f})")
        return

    positions.append((x, y))
    idx = len(positions)

    dot, = ax.plot(x, y, "ko", markersize=6)
    txt = ax.text(x + 0.05, y + 0.05, str(idx), fontsize=8)
    markers.append((dot, txt))

    if idx >= NUM_OBSTACLES:
        redraw_status(f"Đã đủ {NUM_OBSTACLES} vật cản -> đang lưu vào world...")
        fig.canvas.draw_idle()
        plt.pause(0.4)  # cho người dùng kịp thấy điểm cuối trước khi đóng
        plt.close(fig)
        return

    redraw_status(f"Đã đặt vật cản #{idx}/{NUM_OBSTACLES} tại ({x:.2f}, {y:.2f})")
    fig.canvas.draw_idle()


def on_key(event):
    if event.key == "z":
        if positions:
            positions.pop()
            dot, txt = markers.pop()
            dot.remove()
            txt.remove()
            redraw_status(f"Đã xoá vật cản cuối cùng ({len(positions)}/{NUM_OBSTACLES})")
            fig.canvas.draw_idle()
    elif event.key == "c":
        positions.clear()
        for dot, txt in markers:
            dot.remove()
            txt.remove()
        markers.clear()
        redraw_status(f"Đã xoá hết vật cản (0/{NUM_OBSTACLES})")
        fig.canvas.draw_idle()
    elif event.key == "q":
        plt.close(fig)


fig.canvas.mpl_connect("button_press_event", on_click)
fig.canvas.mpl_connect("key_press_event", on_key)

plt.show()  # dừng ở đây cho đến khi người dùng đóng cửa sổ


# ==========================================================
# SAU KHI ĐÓNG CỬA SỔ -> SINH XML VÀ GHI VÀO WORLD
# ==========================================================

if not positions:
    print("Không có vật cản nào được đặt. Không ghi gì vào world.")
    raise SystemExit

color_gen = itertools.cycle(COLOR_CYCLE)

xml = ""
for i, (x, y) in enumerate(positions):
    color = next(color_gen)
    xml += f"""
<model name="cylinder_{i+1}">
    <static>true</static>

    <pose>{x:.3f} {y:.3f} {HEIGHT/2:.2f} 0 0 0</pose>

    <link name="link">

        <collision name="collision">
            <geometry>
                <cylinder>
                    <radius>{RADIUS}</radius>
                    <length>{HEIGHT}</length>
                </cylinder>
            </geometry>
        </collision>

        <visual name="visual">
            <geometry>
                <cylinder>
                    <radius>{RADIUS}</radius>
                    <length>{HEIGHT}</length>
                </cylinder>
            </geometry>

            <material>
                <script>
                    <uri>file://media/materials/scripts/gazebo.material</uri>
                    <name>Gazebo/{color}</name>
                </script>
            </material>

        </visual>

    </link>

</model>

"""

with open(WORLD_FILE, "r") as f:
    world = f.read()

START_MARKER = "<!-- RANDOM_OBSTACLES_START -->"
END_MARKER = "<!-- RANDOM_OBSTACLES_END -->"

begin = world.find(START_MARKER)
finish = world.find(END_MARKER)

if begin == -1 or finish == -1:
    print("Không tìm thấy marker!")
    raise SystemExit

finish += len(END_MARKER)

new_block = f"""{START_MARKER}

{xml}

{END_MARKER}
"""

world = world[:begin] + new_block + world[finish:]

with open(WORLD_FILE, "w") as f:
    f.write(world)

print("============================================")
print(f"Đã ghi {len(positions)} vật cản theo đúng vị trí đã chấm")
print("============================================")
for i, (x, y) in enumerate(positions):
    print(f"{i+1:02d}: ({x:.3f}, {y:.3f})")
print("============================================")
print("Đã cập nhật:", WORLD_FILE)
print("============================================")